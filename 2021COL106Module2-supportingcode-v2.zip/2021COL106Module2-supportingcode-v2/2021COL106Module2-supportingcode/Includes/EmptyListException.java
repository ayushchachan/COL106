package Includes;

public class EmptyListException extends Exception{
	
	public EmptyListException(){
		System.out.println("Error: List Empty");
	}

}